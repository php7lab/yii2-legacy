<?php

namespace yii2bundle\geo\tests\_fixtures;

use yii\test\ActiveFixture;

class GeoRegionFixture extends ActiveFixture
{
	public $tableName = '{{%geo_region}}';
}