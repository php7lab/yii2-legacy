<?php

namespace yii2bundle\geo\tests\_fixtures;

use yii\test\ActiveFixture;

class GeoCityFixture extends ActiveFixture
{
	public $tableName = '{{%geo_city}}';
}