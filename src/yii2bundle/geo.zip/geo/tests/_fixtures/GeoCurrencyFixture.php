<?php

namespace yii2bundle\geo\tests\_fixtures;

use yii\test\ActiveFixture;

class GeoCurrencyFixture extends ActiveFixture
{
	public $tableName = '{{%geo_currency}}';
}