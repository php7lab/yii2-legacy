<?php

namespace yii2bundle\geo\tests\_fixtures;

use yii\test\ActiveFixture;

class GeoCountryFixture extends ActiveFixture
{
	public $tableName = '{{%geo_country}}';
}