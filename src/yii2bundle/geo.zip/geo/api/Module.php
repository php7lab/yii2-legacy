<?php

namespace yii2bundle\geo\api;

use yii\base\Module as YiiModule;

/**
 * geo module definition class
 */
class Module extends YiiModule
{
	
}
