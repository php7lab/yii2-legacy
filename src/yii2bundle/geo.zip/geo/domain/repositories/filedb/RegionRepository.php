<?php

namespace yii2bundle\geo\domain\repositories\filedb;

use yii2rails\extension\filedb\repositories\base\BaseActiveFiledbRepository;

class RegionRepository extends BaseActiveFiledbRepository {
	
	protected $schemaClass = true;
	
}
