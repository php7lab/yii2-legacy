<?php

namespace yii2bundle\geo\domain\interfaces\repositories;

/**
 * Interface RepositoriesInterface
 * 
 * @package yii2bundle\geo\domain\interfaces\repositories
 * 
 * @property-read \yii2bundle\geo\domain\interfaces\repositories\PhoneInterface $phone
 */
interface RepositoriesInterface {

}
