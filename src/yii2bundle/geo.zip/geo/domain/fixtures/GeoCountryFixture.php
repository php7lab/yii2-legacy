<?php

namespace yii2bundle\geo\domain\fixtures;

use yii\test\ActiveFixture;

class GeoCountryFixture extends ActiveFixture
{
	public $tableName = '{{%geo_country}}';
}