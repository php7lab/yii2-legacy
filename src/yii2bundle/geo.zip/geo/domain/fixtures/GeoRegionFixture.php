<?php

namespace yii2bundle\geo\domain\fixtures;

use yii\test\ActiveFixture;

class GeoRegionFixture extends ActiveFixture
{
	public $tableName = '{{%geo_region}}';
}