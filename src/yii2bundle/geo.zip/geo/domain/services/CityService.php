<?php

namespace yii2bundle\geo\domain\services;

use yii2rails\domain\data\Query;
use yii2rails\domain\services\base\BaseActiveService;

class CityService extends BaseActiveService {

}
