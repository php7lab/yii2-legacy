<?php

namespace yii2bundle\geo\domain\services;

use yii2rails\domain\services\base\BaseActiveService;

class CountryService extends BaseActiveService {

}
