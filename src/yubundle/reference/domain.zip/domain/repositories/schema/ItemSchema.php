<?php

namespace yubundle\reference\domain\repositories\schema;

use yii2rails\domain\repositories\relations\BaseSchema;

/**
 * Class ItemSchema
 * 
 * @package yubundle\reference\domain\repositories\schema
 * 
 */
class ItemSchema extends BaseSchema {

}
